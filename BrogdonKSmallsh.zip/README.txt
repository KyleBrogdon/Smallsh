# Kyle Brogdon
# CS 344, Introduction To Operating Systems
# Last Modified: 02 MAY 2022, 1642

To compile the code and run the program, use gcc -std=c99 -o //desiredfilename// main.c